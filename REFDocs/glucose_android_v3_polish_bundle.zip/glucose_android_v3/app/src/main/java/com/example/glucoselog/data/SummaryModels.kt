package com.example.glucoselog.data

data class SummaryStats(
    val count: Int = 0,
    val avgCgm: Double = 0.0,
    val avgManual: Double = 0.0,
    val avgDifference: Double = 0.0,
    val maxCgm: Int = 0,
    val minCgm: Int = 0,
    val maxManual: Int = 0,
    val minManual: Int = 0,
    val contextCounts: Map<String, Int> = emptyMap()
)

data class GlucoseFormState(
    val entryId: Long? = null,
    val dateTimeText: String = "",
    val cgmText: String = "",
    val manualText: String = "",
    val contextTag: ReadingContext = ReadingContext.BEFORE_MEAL,
    val noteText: String = "",
    val isEditing: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

data class ReminderUiState(
    val enabled: Boolean = false,
    val hour: Int = 20,
    val minute: Int = 0,
    val statusMessage: String? = null
)